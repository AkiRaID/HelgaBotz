# TOC
   - [Find](#find)
   - [Misc](#misc)
<a name=""></a>
 
<a name="find"></a>
# Find
<a name="misc"></a>
# Misc
.

```js
expect( term ).to.be.an( termkit.Terminal ) ;
```

