
<a name="top"></a>
<a name="ref.EditableTextBox"></a>
## EditableTextBox

TODOC
