
<a name="top"></a>
<a name="ref.AnimatedText"></a>
## AnimatedText

TODOC
